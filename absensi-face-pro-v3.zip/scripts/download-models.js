const https = require('https');
const fs = require('fs');
const path = require('path');

const BASE = 'https://raw.githubusercontent.com/justadudewhohacks/face-api.js/master/weights/';
const FILES = [
  'tiny_face_detector_model-weights_manifest.json',
  'tiny_face_detector_model-shard1',
  'face_landmark_68_model-weights_manifest.json',
  'face_landmark_68_model-shard1',
  'face_recognition_model-weights_manifest.json',
  'face_recognition_model-shard1',
  'face_recognition_model-shard2'
];
const OUT = path.join(__dirname, '..', 'public', 'models');
fs.mkdirSync(OUT, { recursive: true });

function download(name, attempt = 1) {
  return new Promise((resolve, reject) => {
    const target = path.join(OUT, name);
    const tmp = target + '.part';
    const file = fs.createWriteStream(tmp);
    const req = https.get(BASE + name, { headers: { 'User-Agent': 'absensi-face-recognition' } }, res => {
      if (res.statusCode !== 200) {
        file.close();
        fs.rmSync(tmp, { force: true });
        res.resume();
        return reject(new Error(`${name}: HTTP ${res.statusCode}`));
      }
      res.pipe(file);
      file.on('finish', () => file.close(() => {
        fs.renameSync(tmp, target);
        resolve();
      }));
    });
    req.setTimeout(30000, () => req.destroy(new Error('timeout')));
    req.on('error', err => {
      file.close();
      fs.rmSync(tmp, { force: true });
      reject(err);
    });
  }).catch(async err => {
    if (attempt < 3) {
      console.log(`Retry ${attempt + 1}/3: ${name}`);
      await new Promise(r => setTimeout(r, 1200 * attempt));
      return download(name, attempt + 1);
    }
    throw err;
  });
}

(async () => {
  console.log('Downloading face recognition models...');
  for (const name of FILES) {
    const target = path.join(OUT, name);
    if (fs.existsSync(target) && fs.statSync(target).size > 0) {
      console.log(`✓ ${name} already exists`);
      continue;
    }
    console.log(`↓ ${name}`);
    await download(name);
  }
  console.log('✓ All models are ready in public/models');
})().catch(err => {
  console.error('\nMODEL DOWNLOAD FAILED:', err.message);
  process.exit(1);
});
