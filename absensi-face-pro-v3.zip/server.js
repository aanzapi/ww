require('dotenv').config();
const express = require('express');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const XLSX = require('xlsx');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || '127.0.0.1';
const DB = path.join(__dirname, 'database');
const USERS = path.join(DB, 'users.json');
const ATT = path.join(DB, 'attendance.json');
const THRESHOLD = Number(process.env.FACE_MATCH_THRESHOLD || 0.52);
const DUP_THRESHOLD = Number(process.env.REGISTER_DUPLICATE_THRESHOLD || 0.52);
const SCAN_INTERVAL = Number(process.env.SCAN_INTERVAL_MS || 850);
const SESSION_TTL = Number(process.env.SESSION_TTL_MS || 28800000);
const sessions = new Map();
const rate = new Map();

fs.mkdirSync(DB, { recursive: true });
for (const f of [USERS, ATT]) if (!fs.existsSync(f)) fs.writeFileSync(f, '[]');

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.disable('x-powered-by');
app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true, limit: '100kb' }));
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'same-origin');
  res.setHeader('Permissions-Policy', 'camera=(self)');
  next();
});
app.use(express.static(path.join(__dirname, 'public'), { maxAge: process.env.NODE_ENV === 'production' ? '1h' : 0 }));
app.get('/vendor/face-api.min.js', (req, res) => {
  res.sendFile(path.join(__dirname, 'node_modules', 'face-api.js', 'dist', 'face-api.min.js'));
});

const read = file => { try { const d = JSON.parse(fs.readFileSync(file, 'utf8')); return Array.isArray(d) ? d : []; } catch { return []; } };
function write(file, data) {
  const tmp = `${file}.${process.pid}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2));
  fs.renameSync(tmp, file);
}
function clean(s, max = 80) { return String(s ?? '').trim().replace(/[<>]/g, '').slice(0, max); }
function validDescriptor(d) { return Array.isArray(d) && d.length === 128 && d.every(n => Number.isFinite(Number(n))); }
function normalizeDescriptors(input) {
  const list = Array.isArray(input) && input.length && Array.isArray(input[0]) ? input : [input];
  return list.filter(validDescriptor).map(a => a.map(Number));
}
function distance(a, b) { let sum = 0; for (let i = 0; i < 128; i++) { const x = Number(a[i]) - Number(b[i]); sum += x * x; } return Math.sqrt(sum); }
function bestMatch(descriptors, users) {
  let best = null;
  for (const user of users) {
    for (const stored of user.descriptors || (user.descriptor ? [user.descriptor] : [])) {
      if (!validDescriptor(stored)) continue;
      for (const incoming of descriptors) {
        const d = distance(incoming, stored);
        if (!best || d < best.distance) best = { user, distance: d };
      }
    }
  }
  return best;
}
function dayKey(date = new Date()) { return new Intl.DateTimeFormat('en-CA', { timeZone: process.env.TZ || 'Asia/Jakarta' }).format(date); }
function timeLabel(iso) { return new Date(iso).toLocaleString('id-ID', { timeZone: process.env.TZ || 'Asia/Jakarta' }); }
function adminCookie(req) { const raw = req.headers.cookie || ''; const m = raw.match(/(?:^|; )admin_session=([^;]+)/); return m ? decodeURIComponent(m[1]) : null; }
function isAdmin(req) { const token = adminCookie(req); const s = token && sessions.get(token); if (!s) return false; if (Date.now() > s.expires) { sessions.delete(token); return false; } return true; }
function requireAdmin(req, res, next) { if (!isAdmin(req)) return req.path.startsWith('/api/') ? res.status(401).json({ ok: false, message: 'Admin login diperlukan.' }) : res.redirect('/admin/login'); next(); }
function hashPassword(password, salt) { return crypto.scryptSync(password, salt, 64).toString('hex'); }
function safeEqual(a, b) { const aa = Buffer.from(a); const bb = Buffer.from(b); return aa.length === bb.length && crypto.timingSafeEqual(aa, bb); }
function checkLimit(key, max = 30, windowMs = 60000) { const now = Date.now(); const arr = (rate.get(key) || []).filter(t => now - t < windowMs); arr.push(now); rate.set(key, arr); return arr.length <= max; }

const ADMIN_USER = process.env.ADMIN_USERNAME || 'AanAdmin';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'AdminAan';
const ADMIN_SALT = 'absen-admin-v3-static-salt';
const ADMIN_HASH = hashPassword(ADMIN_PASSWORD, ADMIN_SALT);

app.get('/', (req, res) => res.render('index'));
app.get('/register', (req, res) => res.render('register'));
app.get('/absen', (req, res) => res.render('absen', { scanInterval: SCAN_INTERVAL, threshold: THRESHOLD }));
app.get('/admin/login', (req, res) => res.render('admin-login'));
app.get('/admin', requireAdmin, (req, res) => res.render('admin'));

app.get('/api/config', (req, res) => res.json({ ok: true, scanInterval: SCAN_INTERVAL, threshold: THRESHOLD, duplicateThreshold: DUP_THRESHOLD }));

app.post('/api/register', (req, res) => {
  if (!checkLimit(`register:${req.ip}`, 20, 60000)) return res.status(429).json({ ok: false, message: 'Terlalu banyak percobaan. Coba lagi nanti.' });
  const name = clean(req.body.name, 80), role = clean(req.body.role, 60), descriptors = normalizeDescriptors(req.body.descriptors || req.body.descriptor);
  if (!name || !role || descriptors.length < 1) return res.status(400).json({ ok: false, message: 'Nama, jabatan, dan minimal satu hasil scan wajah wajib diisi.' });
  const users = read(USERS);
  const duplicate = bestMatch(descriptors, users);
  if (duplicate && duplicate.distance < DUP_THRESHOLD) {
    return res.status(409).json({ ok: false, code: 'FACE_ALREADY_REGISTERED', message: 'Wajah sudah terdaftar.', existing: { name: duplicate.user.name, role: duplicate.user.role, distance: Number(duplicate.distance.toFixed(4)) } });
  }
  const key = name.toLowerCase();
  if (users.some(u => String(u.name).toLowerCase() === key)) return res.status(409).json({ ok: false, message: 'Nama tersebut sudah terdaftar.' });
  const user = { id: 'USR-' + crypto.randomBytes(6).toString('hex').toUpperCase(), name, role, descriptors, createdAt: new Date().toISOString() };
  users.push(user); write(USERS, users);
  res.json({ ok: true, user: { id: user.id, name: user.name, role: user.role } });
});

app.get('/api/users', (req, res) => {
  const users = read(USERS);
  res.json(users.map(u => ({ id: u.id, name: u.name, role: u.role, descriptors: u.descriptors || (u.descriptor ? [u.descriptor] : []) })));
});

app.post('/api/attendance', (req, res) => {
  if (!checkLimit(`attendance:${req.ip}`, 60, 60000)) return res.status(429).json({ ok: false, message: 'Terlalu banyak scan. Tunggu sebentar.' });
  const users = read(USERS), u = users.find(x => x.id === req.body.userId);
  if (!u) return res.status(404).json({ ok: false, message: 'Pengguna tidak ditemukan.' });
  const now = new Date(), att = read(ATT), today = dayKey(now);
  const already = att.find(a => a.userId === u.id && a.dayKey === today);
  if (already) return res.status(409).json({ ok: false, code: 'ALREADY_ATTENDED', message: 'Sudah absen hari ini.', data: { name: u.name, role: u.role, time: timeLabel(already.timestamp), timestamp: already.timestamp } });
  const row = { id: 'ABS-' + crypto.randomBytes(6).toString('hex').toUpperCase(), userId: u.id, name: u.name, role: u.role, timestamp: now.toISOString(), dayKey: today };
  att.push(row); write(ATT, att);
  res.json({ ok: true, data: { name: u.name, role: u.role, time: timeLabel(row.timestamp), timestamp: row.timestamp } });
});

app.post('/api/admin/login', (req, res) => {
  if (!checkLimit(`login:${req.ip}`, 10, 60000)) return res.status(429).json({ ok: false, message: 'Terlalu banyak percobaan login.' });
  const username = clean(req.body.username, 80), password = String(req.body.password || '');
  const hash = hashPassword(password, ADMIN_SALT);
  if (username !== ADMIN_USER || !safeEqual(hash, ADMIN_HASH)) return res.status(401).json({ ok: false, message: 'Username atau password salah.' });
  const token = crypto.randomBytes(32).toString('hex');
  sessions.set(token, { expires: Date.now() + SESSION_TTL });
  res.setHeader('Set-Cookie', `admin_session=${encodeURIComponent(token)}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${Math.floor(SESSION_TTL / 1000)}${process.env.NODE_ENV === 'production' ? '; Secure' : ''}`);
  res.json({ ok: true });
});
app.post('/api/admin/logout', requireAdmin, (req, res) => { const token = adminCookie(req); if (token) sessions.delete(token); res.setHeader('Set-Cookie', 'admin_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0'); res.json({ ok: true }); });

app.get('/api/admin/dashboard', requireAdmin, (req, res) => {
  const users = read(USERS), att = read(ATT), today = dayKey();
  const todayRows = att.filter(a => a.dayKey === today);
  res.json({ ok: true, stats: { totalUsers: users.length, todayPresent: todayRows.length, todayAbsent: Math.max(0, users.length - todayRows.length), totalAttendance: att.length }, recent: att.slice().sort((a,b) => b.timestamp.localeCompare(a.timestamp)).slice(0, 30).map(a => ({ ...a, time: timeLabel(a.timestamp) })) });
});

app.get('/api/admin/attendance', requireAdmin, (req, res) => {
  const att = read(ATT).slice().sort((a,b) => b.timestamp.localeCompare(a.timestamp));
  res.json({ ok: true, rows: att.map(a => ({ ...a, time: timeLabel(a.timestamp) })) });
});
app.get('/api/admin/users', requireAdmin, (req, res) => res.json({ ok: true, users: read(USERS).map(u => ({ id:u.id, name:u.name, role:u.role, createdAt:u.createdAt })) }));

app.get('/api/admin/export.csv', requireAdmin, (req, res) => {
  const rows = read(ATT).map(a => ({ Tanggal: a.dayKey, Nama: a.name, Jabatan: a.role, Waktu: timeLabel(a.timestamp), Status: 'Hadir', ID: a.userId }));
  const headers = ['Tanggal','Nama','Jabatan','Waktu','Status','ID'];
  const csv = [headers.join(','), ...rows.map(r => headers.map(h => `"${String(r[h] ?? '').replace(/"/g, '""')}"`).join(','))].join('\n');
  res.setHeader('Content-Type','text/csv; charset=utf-8'); res.setHeader('Content-Disposition','attachment; filename="absensi.csv"'); res.send('\uFEFF' + csv);
});
app.get('/api/admin/export.xlsx', requireAdmin, (req, res) => {
  const rows = read(ATT).map(a => ({ Tanggal: a.dayKey, Nama: a.name, Jabatan: a.role, Waktu: timeLabel(a.timestamp), Status: 'Hadir', ID: a.userId }));
  const wb = XLSX.utils.book_new(); const ws = XLSX.utils.json_to_sheet(rows); XLSX.utils.book_append_sheet(wb, ws, 'Absensi');
  const buf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
  res.setHeader('Content-Type','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'); res.setHeader('Content-Disposition','attachment; filename="absensi.xlsx"'); res.send(buf);
});

app.post('/api/admin/reset', requireAdmin, (req, res) => {
  const confirm = String(req.body.confirm || '');
  if (confirm !== 'RESET DATABASE') return res.status(400).json({ ok:false, message:'Konfirmasi harus tepat: RESET DATABASE' });
  write(USERS, []); write(ATT, []); res.json({ ok:true, message:'Semua database berhasil direset.' });
});

setInterval(() => { const now = Date.now(); for (const [k,v] of sessions) if (v.expires < now) sessions.delete(k); for (const [k,v] of rate) { const fresh=v.filter(t=>now-t<60000); if(fresh.length) rate.set(k,fresh); else rate.delete(k); } }, 60000).unref();

app.listen(PORT, HOST, () => console.log(`Absensi PRO running on http://${HOST}:${PORT}`));
