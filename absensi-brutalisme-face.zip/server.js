require("dotenv").config();
const express=require("express");
const path=require("path");
const fs=require("fs");
const app=express();
const PORT=process.env.PORT||3000;
const DB=path.join(__dirname,"database");
const USERS=path.join(DB,"users.json");
const ATT=path.join(DB,"attendance.json");
fs.mkdirSync(DB,{recursive:true});
for(const f of [USERS,ATT]) if(!fs.existsSync(f)) fs.writeFileSync(f,"[]");
app.set("view engine","ejs"); app.set("views",path.join(__dirname,"views"));
app.use(express.json({limit:"2mb"})); app.use(express.urlencoded({extended:true}));
app.use(express.static(path.join(__dirname,"public")));
const read=f=>{try{return JSON.parse(fs.readFileSync(f,"utf8"))}catch{return[]}};
const write=(f,d)=>fs.writeFileSync(f,JSON.stringify(d,null,2));
app.get("/",(_,res)=>res.render("index"));
app.get("/register",(_,res)=>res.render("register"));
app.get("/absen",(_,res)=>res.render("absen"));

app.post("/api/register",(req,res)=>{
 const {name,role,descriptor}=req.body;
 if(!name?.trim()||!role?.trim()||!Array.isArray(descriptor)||descriptor.length!==128)
  return res.status(400).json({ok:false,message:"Data registrasi belum lengkap."});
 const users=read(USERS), key=name.trim().toLowerCase();
 if(users.some(u=>u.name.toLowerCase()===key))
  return res.status(409).json({ok:false,message:"Nama tersebut sudah terdaftar."});
 const user={id:"USR-"+Date.now(),name:name.trim(),role:role.trim(),descriptor,createdAt:new Date().toISOString()};
 users.push(user);write(USERS,users);
 res.json({ok:true,user:{name:user.name,role:user.role}});
});

app.get("/api/users",(req,res)=>{
 res.json(read(USERS).map(u=>({id:u.id,name:u.name,role:u.role,descriptor:u.descriptor})));
});

app.post("/api/attendance",(req,res)=>{
 const users=read(USERS),u=users.find(x=>x.id===req.body.userId);
 if(!u)return res.status(404).json({ok:false,message:"Pengguna tidak ditemukan."});
 const now=new Date(),att=read(ATT);
 att.push({id:"ABS-"+Date.now(),userId:u.id,name:u.name,role:u.role,timestamp:now.toISOString()});
 write(ATT,att);
 res.json({ok:true,data:{name:u.name,role:u.role,time:now.toLocaleString("id-ID")}});
});
app.listen(PORT,()=>console.log(`Absensi: http://localhost:${PORT}`));