const https=require("https"),fs=require("fs"),path=require("path");
const base="https://raw.githubusercontent.com/justadudewhohacks/face-api.js/master/weights/";
const files=[
"tiny_face_detector_model-weights_manifest.json","tiny_face_detector_model-shard1",
"face_landmark_68_model-weights_manifest.json","face_landmark_68_model-shard1",
"face_recognition_model-weights_manifest.json","face_recognition_model-shard1","face_recognition_model-shard2"
];
const out=path.join(__dirname,"..","public","models");fs.mkdirSync(out,{recursive:true});
function dl(name){return new Promise((resolve,reject)=>{const f=fs.createWriteStream(path.join(out,name));https.get(base+name,r=>{if(r.statusCode!==200){f.close();fs.unlinkSync(path.join(out,name));return reject(new Error(name+" HTTP "+r.statusCode))}r.pipe(f);f.on("finish",()=>f.close(resolve))}).on("error",reject)})}
(async()=>{for(const f of files){console.log("Downloading",f);await dl(f)}console.log("Models ready.")})().catch(e=>{console.error(e);process.exit(1)})