MODEL FACE-API.JS
This folder is intentionally kept small in the ZIP.
Run:
  npm run models
The script downloads the Tiny Face Detector, 68-point landmarks and face recognition model files
from the face-api.js model repository into this folder.
